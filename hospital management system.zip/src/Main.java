import java.io.IOException;

public class Main {

	public static void main(String[] args) throws IOException {
		
		
		///Read input File
		Implantation.ReadInputFile(args[0]);
		
	}

	
}
